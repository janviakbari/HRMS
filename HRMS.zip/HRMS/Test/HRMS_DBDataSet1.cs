﻿namespace Test {
    
    
    public partial class HRMS_DBDataSet1 {
    }
}
